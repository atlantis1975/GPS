// <!--1.6-->
require("UIColor", 'NSMutableArray')

defineClass("LCAppsLocationController", {
    viewDidLoad: function() {
        self.ORIGviewDidLoad();
    }
});
